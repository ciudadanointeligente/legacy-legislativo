<h1>Editar Proyecto ley</h1>

<?php include_partial('form', array('form' => $form)) ?>
