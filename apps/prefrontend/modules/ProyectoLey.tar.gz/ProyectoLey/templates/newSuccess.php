<h1>Agregar Proyecto de Ley</h1>

<?php include_partial('form', array('form' => $form)) ?>
